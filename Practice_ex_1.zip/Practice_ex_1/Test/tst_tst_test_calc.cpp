#include <QtTest>
#include"../Calc/Calc.h"

// add necessary includes here

class tst_test_Calc : public QObject
{
    Q_OBJECT

public:
    tst_test_Calc();
    ~tst_test_Calc();

private slots:
    void test_case1();
    void test_case2();




};

tst_test_Calc::tst_test_Calc() {}

tst_test_Calc::~tst_test_Calc() {}
void tst_test_Calc::test_case1() {
    Calc a;
    QCOMPARE(a.gcd(10,5),5);
    QCOMPARE(a.gcd(2147483647,52),1);
    QCOMPARE(a.gcd(100,52),4);
    QCOMPARE(a.gcd(1488,64),16);
    QCOMPARE(a.gcd(10,-5),-5);


}
void tst_test_Calc::test_case2(){
    Calc a;
    QCOMPARE(a.gcd(1000,52),4);
    QCOMPARE(a.gcd(14880,64),32);
    QCOMPARE(a.gcd(10,-10),-10);
}

QTEST_APPLESS_MAIN(tst_test_Calc)

#include "tst_tst_test_calc.moc"
