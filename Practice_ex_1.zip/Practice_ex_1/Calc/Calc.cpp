#include "Calc.h"
Calc::gcd(int a, int b){
    if(a==0){
        return b;
    }
    if(b==0){
        return a;
    }
    int r=a%b;
    return gcd(b,r);

}
