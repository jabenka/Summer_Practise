#pragma once
class Calc{
public:

    int gcd(int a,int b);
};
